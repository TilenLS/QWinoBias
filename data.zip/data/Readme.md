If you want to convert your winobias format dataset to conll dataset, you can refer to [here](https://github.com/JieyuZhao/toWino).
